import { useState } from 'react'
import { Sheet, baht, dshort } from '../../components/ui'
import { searchAll, statusLabel } from '../../lib/search'
import { TYPES } from '../../lib/ledger'

export default function Search({ data, onClose }) {
  const [q, setQ] = useState('')
  const r = q.trim() ? searchAll(q, data) : null
  return (
    <Sheet title="ค้นหา" onClose={onClose}><div className="form">
      <input autoFocus placeholder="ชื่อ เบอร์ เลขบิล สินค้า วันที่ (2026-09-29) หรือสถานะ" value={q} onChange={(e) => setQ(e.target.value)} />
      {r && !r.customers.length && !r.bills.length && !r.txs.length && <div className="mut">ไม่พบรายการที่ตรงกับ “{q}”</div>}
      {r?.customers.length > 0 && <div className="list"><b>ลูกค้า</b>{r.customers.map((c) => <div className="row" key={c.id}><span>{c.name}</span><span className="mut">{c.phone}</span></div>)}</div>}
      {r?.bills.length > 0 && <div className="list"><b>บิล</b>{r.bills.map((b) => <div className="row" key={b.id}>
        <span>{b.kind} {b.billNo} · {b.customerName}<div className="mut">{statusLabel(b.st)} · ครบ {dshort(b.dueDate)}</div></span><b>{baht(b.remain)}</b></div>)}</div>}
      {r?.txs.length > 0 && <div className="list"><b>รายการเงินเข้า-ออก</b>{r.txs.map((t) => <div className="row" key={t.id}>
        <span>{TYPES[t.type]} {t.billNo}<div className="mut">{dshort(t.date)} {t.customerName}</div></span><b>{t.amount.toLocaleString('th-TH')}</b></div>)}</div>}
      <button className="btn" onClick={onClose}>ปิด</button></div></Sheet>)
}
