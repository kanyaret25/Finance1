import { useState } from 'react'
import { Sheet, baht, dshort, useAction } from '../../components/ui'
import { TYPES } from '../../lib/ledger'
import { voidTx } from '../../lib/db'

const IN = ['principal_in', 'profit_in', 'credit_paid_cost', 'credit_paid_profit', 'other_income', 'capital_in']
const MANUAL = ['expense', 'personal_withdrawal', 'capital_in', 'capital_out', 'other_income'] // รายการที่ไม่ผูกกับบิล ยกเลิกได้ปลอดภัย

export default function TxView({ txs }) {
  const [target, setTarget] = useState(null), { busy, err, run } = useAction()
  const voided = new Set(txs.map((t) => t.voidOf).filter(Boolean))
  const rows = [...txs].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 100)
  return (
    <>
      <div className="card list">{rows.map((t) => { const v = (IN.includes(t.type) ? 1 : -1) * t.amount; const dead = voided.has(t.id) || t.voidOf; return (
        <div className="row" key={t.id} style={{ opacity: dead ? 0.5 : 1 }}>
          <div>{TYPES[t.type]}{t.billNo ? ' ' + t.billNo : ''}{t.customerName ? ' · ' + t.customerName : ''}
            <div className="mut">{dshort(t.date)}{t.voidOf ? ' · ยกเลิก' : voided.has(t.id) ? ' · ถูกยกเลิกแล้ว' : ''}</div>
            {MANUAL.includes(t.type) && !dead && <button className="link" onClick={() => setTarget(t)}>ยกเลิกรายการ</button>}</div>
          <b className={v < 0 ? 'r' : 'g'}>{v < 0 ? '−' : '+'}{Math.abs(t.amount).toLocaleString('th-TH')}</b></div>) })}
        {!rows.length && <div className="mut">ยังไม่มีรายการ</div>}</div>
      <div className="note">รายการที่ผูกกับบิลเงินกู้/เครดิตจะยกเลิกจากหน้านี้ไม่ได้ เพื่อไม่ให้ยอดบิลกับ ledger ไม่ตรงกัน</div>
      {target && <Sheet title="ยกเลิกรายการนี้?" onClose={() => setTarget(null)}>
        <p>{TYPES[target.type]} {baht(target.amount)}<br /><span className="mut">ระบบจะสร้างรายการกลับรายการ ของเดิมยังตรวจย้อนหลังได้</span></p>
        {err && <div className="r">{err}</div>}
        <div className="btns"><button className="btn sec" onClick={() => setTarget(null)}>ไม่ยกเลิก</button>
          <button className="btn" disabled={busy} onClick={async () => (await run(() => voidTx(target, txs))) && setTarget(null)}>ยืนยันยกเลิก</button></div></Sheet>}
    </>
  )
}
