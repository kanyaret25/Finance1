const T = { home: ['🏠', 'หน้าแรก'], customers: ['👥', 'ลูกค้า'], loans: ['💸', 'เงินกู้'], credit: ['🛒', 'เครดิต'], reports: ['📊', 'รายงาน'] }
export default function BottomNav({ tab, onChange, onAdd }) {
  const b = (k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => onChange(k)}><span>{T[k][0]}</span>{T[k][1]}</button>
  return (
    <nav className="nav">
      {b('home')}{b('customers')}
      <button className="fab" aria-label="เพิ่มรายการ" onClick={onAdd}>+</button>
      {b('loans')}{b('credit')}{b('reports')}
    </nav>
  )
}
