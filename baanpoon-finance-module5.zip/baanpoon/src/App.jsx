import { useState } from 'react'
import { signOut } from 'firebase/auth'
import { auth } from './lib/firebase'
import { useAuth } from './hooks/useAuth'
import { useData } from './hooks/useData'
import { computeSummary } from './lib/ledger'
import { addTx, saveSettings } from './lib/db'
import Login from './features/auth/Login'
import BottomNav from './components/BottomNav'
import Dashboard from './features/dashboard/Dashboard'
import Customers from './features/customers/Customers'
import Loans from './features/loans/Loans'
import Credit from './features/credit/Credit'
import Reports from './features/reports/Reports'
import Search from './features/search/Search'
import { AmountForm, Sheet, baht, useAction } from './components/ui'

export default function App() {
  const { user, loading } = useAuth()
  if (loading) return <p className="muted center">กำลังโหลด…</p>
  return user ? <Main /> : <Login />
}

function Main() {
  const data = useData(), [tab, setTab] = useState('home'), [sheet, setSheet] = useState(null)
  if (!data.ready) return <p className="muted center">กำลังโหลด…</p>
  if (!data.settings) return <Setup />
  const s = computeSummary(data.transactions, data.settings), close = () => setSheet(null)
  const quick = (type, category) => (amount, note) => addTx({ type, amount, category, note })
  const withdraw = (amount, note) => {
    if (amount > s.profitBalance) throw new Error(`ถอนเกินกำไรคงเหลือ (${baht(s.profitBalance)})`)
    return addTx({ type: 'personal_withdrawal', amount, category: 'ถอนกำไร', note })
  }
  const acts = [['💸', 'ปล่อยกู้', () => { setTab('loans'); close() }], ['🛒', 'ขายเครดิตสินค้า', () => { setTab('credit'); close() }], ['💵', 'รับชำระเครดิต', () => { setTab('credit'); close() }], ['📤', 'ถอนใช้ส่วนตัว', () => setSheet('withdraw')],
    ['💳', 'ค่าใช้จ่าย', () => setSheet('expense')], ['💰', 'เพิ่มเงินทุน', () => setSheet('capital')]]
  return (
    <div className="app">
      <div className="row"><span><button className="link" onClick={() => setSheet('search')}>🔍 ค้นหา</button> <button className="link" onClick={() => setSheet('settings')}>⚙️ ตั้งค่า</button></span><button className="link" onClick={() => signOut(auth)}>ออกจากระบบ</button></div>
      {tab === 'home' && <Dashboard data={data} />}
      {tab === 'customers' && <Customers customers={data.customers} loans={data.loans} creditSales={data.creditSales} transactions={data.transactions} />}
      {tab === 'loans' && <Loans customers={data.customers} loans={data.loans} />}
      {tab === 'credit' && <Credit data={data} />}
      {tab === 'reports' && <Reports data={data} />}
      <BottomNav tab={tab} onChange={setTab} onAdd={() => setSheet('fab')} />
      {sheet === 'fab' && <Sheet title="เลือกรายการ" onClose={close}><div className="acts">
        {acts.map((a) => <button key={a[1]} onClick={a[2]}><span>{a[0]}</span>{a[1]}</button>)}</div></Sheet>}
      {sheet === 'withdraw' && <AmountForm title="ถอนกำไรใช้ส่วนตัว" label="ยืนยันการถอน" hint={`กำไรคงเหลือ ${baht(s.profitBalance)} (ไม่นับเป็นค่าใช้จ่ายธุรกิจ)`} onSubmit={withdraw} onClose={close} />}
      {sheet === 'expense' && <AmountForm title="ค่าใช้จ่ายธุรกิจ" label="บันทึก" onSubmit={quick('expense', 'ค่าใช้จ่าย')} onClose={close} />}
      {sheet === 'capital' && <AmountForm title="เพิ่มเงินทุน" label="บันทึก" onSubmit={quick('capital_in', 'เงินทุน')} onClose={close} />}
      {sheet === 'search' && <Search data={data} onClose={close} />}
      {sheet === 'settings' && <SettingsSheet settings={data.settings} onClose={close} />}
    </div>
  )
}

function Setup() {
  const [v, setV] = useState('20000')
  return (
    <div className="login"><h1>ตั้งค่าครั้งแรก</h1><p className="muted">เงินทุนเริ่มต้นของธุรกิจเท่าไหร่? ตั้งได้ครั้งเดียว หลังจากนี้ปรับด้วย “เพิ่ม/ถอนเงินทุน”</p>
      <input type="number" inputMode="decimal" value={v} onChange={(e) => setV(e.target.value)} />
      <button className="btn" disabled={!(+v >= 0)} onClick={() => saveSettings({ startingCapital: +v })}>เริ่มใช้งาน</button></div>
  )
}

function SettingsSheet({ settings, onClose }) {
  const [v, setV] = useState(String(settings.lowCapitalAlert ?? '')), { busy, err, run } = useAction()
  return (
    <Sheet title="ตั้งค่า" onClose={onClose}><div className="form">
      <div className="mut">เตือนเมื่อทุนที่พร้อมหมุนต่ำกว่า (บาท) · เว้นว่างหรือ 0 = ไม่เตือน</div>
      <input type="number" inputMode="decimal" placeholder="เช่น 5000" value={v} onChange={(e) => setV(e.target.value)} />
      {err && <div className="r">{err}</div>}
      <button className="btn" disabled={busy} onClick={async () => (await run(() => saveSettings({ lowCapitalAlert: +v || 0 }))) && onClose()}>บันทึก</button></div></Sheet>
  )
}
