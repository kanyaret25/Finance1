import { useState } from 'react'
import { Sheet, baht, dshort, useAction } from '../../components/ui'
import { splitCreditPayment, creditRemain, creditUsed } from '../../lib/ledger'
import { loanStatus, creditStatus } from '../../lib/rules'
import { openCredit, payCredit, saveProduct } from '../../lib/db'

const CH = { normal: ['ok', '🟢 ปกติ'], near: ['warn', '🟡 ใกล้ครบกำหนด'], overdue: ['bad', '🔴 เกินกำหนด'], extended: ['ok', '🟢 ปกติ'], closed: ['done', '⚫ ปิดแล้ว'] }
const CATS = ['อาหารแห้ง', 'ของใช้', 'ของกิน', 'ของใช้ในบ้าน', 'เครื่องสำอาง', 'ของจิปาถะ', 'อื่น ๆ']
const addDays = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10)
const Box = ({ children }) => <div className="card" style={{ margin: 0, background: 'var(--soft)' }}>{children}</div>

export default function Credit({ data }) {
  const { customers, creditSales, products } = data
  const [view, setView] = useState('bills'), [sheet, setSheet] = useState(null), close = () => setSheet(null)
  const open = creditSales.filter((s) => s.status !== 'closed').sort((a, b) => a.dueDate.localeCompare(b.dueDate))
  const limited = customers.filter((c) => c.creditLimit > 0 && creditUsed(creditSales, c.id) > 0)
  return (
    <>
      <h1>เครดิตสินค้า</h1><div className="mut">แยกบัญชีจากเงินกู้</div>
      <div className="tabs" style={{ marginTop: 12 }}>
        <button className={view === 'bills' ? 'on' : ''} onClick={() => setView('bills')}>บิลเครดิต</button>
        <button className={view === 'products' ? 'on' : ''} onClick={() => setView('products')}>สินค้า</button></div>
      {view === 'bills' ? <>
        {limited.map((c) => { const u = creditUsed(creditSales, c.id), st = creditStatus(c.creditLimit, u); return (
          <div className="card" key={c.id}><div className="row"><b>{c.name}</b>
            <span className={'chip ' + (st.level === 'ok' ? 'ok' : st.level === 'near' ? 'warn' : 'bad')}>{st.level === 'ok' ? 'ปกติ' : st.level === 'near' ? 'ใกล้เต็มวงเงิน' : 'เกินวงเงิน'}</span></div>
            <div className="mut">ใช้ไป {baht(u)} จากวงเงิน {baht(c.creditLimit)}</div>
            <div className="bar"><i style={{ width: Math.min(100, u / c.creditLimit * 100) + '%' }} /></div>
            <div className="mut">เหลือ {baht(Math.max(0, st.left))}</div></div>) })}
        {open.map((s) => { const ch = CH[loanStatus(s)]; return (
          <div className="card" key={s.id}>
            <div className="row"><b>{s.billNo} · {s.customerName}</b><span className={'chip ' + ch[0]}>{ch[1]}</span></div>
            <div className="mut">{s.items.map((i) => `${i.name} ×${i.qty}`).join(', ')}</div>
            <div className="row" style={{ marginTop: 8 }}>
              <div><div className="mut">ยอดค้าง</div><b className="r">{baht(creditRemain(s))}</b></div>
              <div><div className="mut">กำไรบิลนี้</div><b className="g">+{s.profit.toLocaleString('th-TH')}</b></div>
              <div><div className="mut">ครบกำหนด</div><b>{dshort(s.dueDate)}</b></div></div>
            <div className="btns"><button className="btn" onClick={() => setSheet(['pay', s])}>รับชำระ</button></div></div>) })}
        {!open.length && <div className="card mut">ยังไม่มีบิลเครดิตที่ค้างอยู่</div>}
        <button className="btn" onClick={() => setSheet(['new'])}>+ ขายเครดิตสินค้า</button></> : <>
        <div className="card list">{products.map((p) => (
          <div className="row" key={p.id} onClick={() => setSheet(['prod', p])} style={{ cursor: 'pointer' }}>
            <div><b>{p.name}</b><div className="mut">{p.category} · ทุน {p.lastCost} → ขาย {p.price}</div></div>
            <div style={{ textAlign: 'right' }}><b>{p.stock ?? '-'}</b><div className="mut">ในสต็อก</div></div></div>))}
          {!products.length && <div className="mut">ยังไม่มีสินค้า เพิ่มสินค้าเพื่อให้กรอกบิลได้เร็วขึ้น</div>}</div>
        <button className="btn" onClick={() => setSheet(['prod'])}>+ เพิ่มสินค้า</button></>}
      {sheet?.[0] === 'new' && <NewCredit customers={customers} sales={creditSales} products={products} onClose={close} />}
      {sheet?.[0] === 'pay' && <Pay sale={sheet[1]} onClose={close} />}
      {sheet?.[0] === 'prod' && <Product p={sheet[1]} onClose={close} />}
    </>
  )
}

const blank = () => ({ pid: '', name: '', qty: '1', cost: '', price: '' })
function NewCredit({ customers, sales, products, onClose }) {
  const [cid, setCid] = useState(customers[0]?.id || ''), [items, setItems] = useState([blank()]), [due, setDue] = useState(addDays(30))
  const { busy, err, run } = useAction()
  const c = customers.find((x) => x.id === cid)
  const upd = (i, patch) => setItems(items.map((it, j) => (j === i ? { ...it, ...patch } : it)))
  const pick = (i, pid) => { const p = products.find((x) => x.id === pid); upd(i, p ? { pid, name: p.name, cost: String(p.lastCost ?? ''), price: String(p.price ?? '') } : { pid: '' }) }
  const rows = items.filter((it) => it.name && +it.qty > 0 && +it.price > 0 && it.cost !== '')
    .map((it) => ({ productId: it.pid || null, name: it.name, qty: +it.qty, cost: +it.cost, price: +it.price }))
  const cost = rows.reduce((s, i) => s + i.qty * i.cost, 0), price = rows.reduce((s, i) => s + i.qty * i.price, 0)
  const used = c ? creditUsed(sales, c.id) : 0, st = creditStatus(c?.creditLimit ?? 0, used + price)
  return (
    <Sheet title="ขายเครดิตสินค้า" onClose={onClose}>
      {!customers.length ? <p className="mut">เพิ่มลูกค้าก่อนที่หน้า “ลูกค้า”</p> : <div className="form">
        <select value={cid} onChange={(e) => setCid(e.target.value)}>{customers.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select>
        <div className="mut">{c?.creditLimit > 0 ? `วงเงินคงเหลือ ${baht(c.creditLimit - used)}` : 'ยังไม่ได้ตั้งวงเงิน (ตั้งที่หน้าลูกค้า)'}</div>
        {items.map((it, i) => <Box key={i}><div className="form">
          {products.length > 0 && <select value={it.pid} onChange={(e) => pick(i, e.target.value)}><option value="">เลือกจากสินค้า (หรือพิมพ์เอง)</option>
            {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>}
          <input placeholder="ชื่อสินค้า" value={it.name} onChange={(e) => upd(i, { name: e.target.value })} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
            <input type="number" inputMode="decimal" placeholder="จำนวน" value={it.qty} onChange={(e) => upd(i, { qty: e.target.value })} />
            <input type="number" inputMode="decimal" placeholder="ทุน/ชิ้น" value={it.cost} onChange={(e) => upd(i, { cost: e.target.value })} />
            <input type="number" inputMode="decimal" placeholder="ขาย/ชิ้น" value={it.price} onChange={(e) => upd(i, { price: e.target.value })} /></div></div></Box>)}
        <button className="btn sec" onClick={() => setItems([...items, blank()])}>+ เพิ่มสินค้าอีกรายการ</button>
        <div className="mut">วันครบกำหนด</div><input type="date" value={due} onChange={(e) => setDue(e.target.value)} />
        {price > 0 && <Box><div className="row"><span>ยอดเครดิต</span><b>{baht(price)}</b></div>
          <div className="row"><span>ต้นทุน</span><b>{baht(cost)}</b></div>
          <div className="row"><span>กำไร</span><b className="g">+{(price - cost).toLocaleString('th-TH')}</b></div>
          {st.level !== 'ok' && <div className={st.level === 'over' ? 'r' : 'mut'}>{st.level === 'over' ? 'เกินวงเงินของลูกค้า' : '⚠️ ใช้วงเงินเกิน 80% แล้ว'}</div>}</Box>}
        {err && <div className="r">{err}</div>}
        <button className="btn" disabled={busy || !c || !rows.length || !due} onClick={async () =>
          (await run(() => openCredit({ customer: c, sales, products, items: rows, dueDate: due }))) && onClose()}>บันทึกบิล</button></div>}
    </Sheet>)
}

function Pay({ sale, onClose }) {
  const [amt, setAmt] = useState(String(creditRemain(sale))), { busy, err, run } = useAction()
  let s = null, msg = ''
  try { if (+amt > 0) s = splitCreditPayment(sale, +amt) } catch (e) { msg = e.message }
  return (
    <Sheet title={`รับชำระ ${sale.billNo} · ${sale.customerName}`} onClose={onClose}><div className="form">
      <div className="mut">ยอดค้าง {baht(creditRemain(sale))}</div>
      <input type="number" inputMode="decimal" value={amt} onChange={(e) => setAmt(e.target.value)} />
      <Box>{s ? <><div className="row"><span>ต้นทุนกลับเข้าทุน</span><b>{baht(s.cost)}</b></div>
        <div className="row"><span>กำไรสะสม</span><b className="g">+{s.profit.toLocaleString('th-TH')}</b></div></> : <span className="r">{msg || 'กรอกจำนวนเงิน'}</span>}</Box>
      {err && <div className="r">{err}</div>}
      <button className="btn" disabled={busy || !s} onClick={async () => (await run(() => payCredit(sale, +amt))) && onClose()}>บันทึกการรับชำระ</button></div></Sheet>)
}

function Product({ p, onClose }) {
  const [f, setF] = useState({ name: p?.name ?? '', sku: p?.sku ?? '', category: p?.category ?? CATS[0], lastCost: p?.lastCost ?? '', price: p?.price ?? '', stock: p?.stock ?? '', source: p?.source ?? '', note: p?.note ?? '' })
  const { busy, err, run } = useAction()
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const num = (v) => (v === '' ? null : +v)
  return (
    <Sheet title={p ? 'แก้ไขสินค้า' : 'เพิ่มสินค้า'} onClose={onClose}><div className="form">
      <input placeholder="ชื่อสินค้า" value={f.name} onChange={set('name')} />
      <input placeholder="SKU (ถ้ามี)" value={f.sku} onChange={set('sku')} />
      <select value={f.category} onChange={set('category')}>{CATS.map((c) => <option key={c}>{c}</option>)}</select>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
        <input type="number" inputMode="decimal" placeholder="ทุนล่าสุด" value={f.lastCost} onChange={set('lastCost')} />
        <input type="number" inputMode="decimal" placeholder="ราคาขาย" value={f.price} onChange={set('price')} />
        <input type="number" inputMode="decimal" placeholder="จำนวน" value={f.stock} onChange={set('stock')} /></div>
      <input placeholder="แหล่งซื้อ" value={f.source} onChange={set('source')} />
      <input placeholder="หมายเหตุ" value={f.note} onChange={set('note')} />
      {err && <div className="r">{err}</div>}
      <button className="btn" disabled={busy || !f.name.trim()} onClick={async () => (await run(() => saveProduct({ id: p?.id, ...f, name: f.name.trim(), lastCost: num(f.lastCost), price: num(f.price), stock: num(f.stock) }))) && onClose()}>บันทึก</button></div></Sheet>)
}
