import { useState } from 'react'
import { Sheet, baht, dshort, useAction } from '../../components/ui'
import { saveCustomer } from '../../lib/db'
import { loanStatus, creditStatus } from '../../lib/rules'
import { creditUsed, creditRemain, TYPES } from '../../lib/ledger'

const IN = ['principal_in', 'profit_in', 'credit_paid_cost', 'credit_paid_profit', 'other_income', 'capital_in']
const rem = (l) => (l.principal - (l.paidPrincipal ?? 0)) + (l.profit - (l.paidProfit ?? 0))

export default function Customers({ customers, loans, creditSales, transactions }) {
  const [sheet, setSheet] = useState(null), close = () => setSheet(null)
  const owed = (id) => creditUsed(creditSales, id) + loans.filter((l) => l.customerId === id && l.status !== 'closed').reduce((s, l) => s + rem(l), 0)
  const late = (id) => [...loans, ...creditSales].some((l) => l.customerId === id && loanStatus(l) === 'overdue')
  return (
    <>
      <h1>ลูกค้า</h1><div className="mut">{customers.length} ราย · ยอดค้างรวม {baht(customers.reduce((s, c) => s + owed(c.id), 0))}</div><h2 />
      <div className="card list">{customers.map((c) => (
        <div className="row" key={c.id} onClick={() => setSheet(['view', c])} style={{ cursor: 'pointer' }}>
          <div><b>{c.name}</b><div className="mut">{c.phone}{c.status === 'inactive' ? ' · ปิดใช้งาน' : ''}</div></div>
          <div style={{ textAlign: 'right' }}><b className={owed(c.id) ? 'r' : ''}>{baht(owed(c.id))}</b><br />
            <span className={'chip ' + (late(c.id) ? 'bad' : 'ok')}>{late(c.id) ? 'เกินกำหนด' : 'ปกติ'}</span></div></div>))}
        {!customers.length && <div className="mut">ยังไม่มีลูกค้า กดปุ่มด้านล่างเพื่อเพิ่มคนแรก</div>}</div>
      <button className="btn" onClick={() => setSheet(['edit'])}>+ เพิ่มลูกค้า</button>
      {sheet?.[0] === 'edit' && <Form c={sheet[1]} onClose={close} />}
      {sheet?.[0] === 'view' && <Detail c={customers.find((x) => x.id === sheet[1].id) ?? sheet[1]} loans={loans} sales={creditSales} txs={transactions} owed={owed(sheet[1].id)}
        onEdit={() => setSheet(['edit', sheet[1]])} onClose={close} />}
    </>
  )
}

function Detail({ c, loans, sales, txs, owed, onEdit, onClose }) {
  const ml = loans.filter((l) => l.customerId === c.id && l.status !== 'closed'), ms = sales.filter((l) => l.customerId === c.id && l.status !== 'closed')
  const used = creditUsed(sales, c.id), hist = txs.filter((t) => t.customerId === c.id).sort((a, b) => b.date.localeCompare(a.date))
  return (
    <Sheet title={c.name} onClose={onClose}>
      <div className="mut">{c.phone} {c.address && '· ' + c.address}</div>{c.note && <div className="mut">📝 {c.note}</div>}
      <div className="card" style={{ background: 'var(--soft)', margin: '12px 0' }}>
        <div className="row"><span>ยอดค้างทั้งหมด</span><b className="r">{baht(owed)}</b></div>
        {c.creditLimit > 0 && <div className="mut">เครดิตสินค้า ใช้ {baht(used)} / วงเงิน {baht(c.creditLimit)} (เหลือ {baht(Math.max(0, creditStatus(c.creditLimit, used).left))})</div>}</div>
      <div className="list">
        {ml.map((l) => <div className="row" key={l.id}><span>💸 {l.billNo} · ต่อดอก {l.extensionCount ?? 0}/4<div className="mut">ครบ {dshort(l.dueDate)}</div></span><b>{baht(rem(l))}</b></div>)}
        {ms.map((l) => <div className="row" key={l.id}><span>🛒 {l.billNo}<div className="mut">{l.items.map((i) => i.name).join(', ')}</div></span><b>{baht(creditRemain(l))}</b></div>)}
        {!ml.length && !ms.length && <div className="mut">ไม่มียอดค้าง</div>}</div>
      <h2>ประวัติรายการ</h2>
      <div className="list">{hist.slice(0, 30).map((t) => <div className="row" key={t.id}><span>{TYPES[t.type]} {t.billNo}<div className="mut">{dshort(t.date)}</div></span>
        <b className={IN.includes(t.type) ? 'g' : 'r'}>{IN.includes(t.type) ? '+' : '−'}{Math.abs(t.amount).toLocaleString('th-TH')}</b></div>)}
        {!hist.length && <div className="mut">ยังไม่มีรายการ</div>}</div>
      <div className="btns"><button className="btn sec" onClick={onEdit}>แก้ไขข้อมูล</button><button className="btn" onClick={onClose}>ปิด</button></div>
    </Sheet>)
}

function Form({ c, onClose }) {
  const [f, setF] = useState({ name: c?.name ?? '', phone: c?.phone ?? '', address: c?.address ?? '', creditLimit: c?.creditLimit ?? '', note: c?.note ?? '', status: c?.status ?? 'active' })
  const { busy, err, run } = useAction(), set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  return (
    <Sheet title={c ? 'แก้ไขลูกค้า' : 'เพิ่มลูกค้า'} onClose={onClose}><div className="form">
      <input placeholder="ชื่อ" value={f.name} onChange={set('name')} />
      <input type="tel" placeholder="เบอร์โทร" value={f.phone} onChange={set('phone')} />
      <input placeholder="ที่อยู่" value={f.address} onChange={set('address')} />
      <input type="number" inputMode="decimal" placeholder="วงเงินเครดิตสินค้า (0 = ไม่ให้เครดิต)" value={f.creditLimit} onChange={set('creditLimit')} />
      <input placeholder="หมายเหตุ" value={f.note} onChange={set('note')} />
      <select value={f.status} onChange={set('status')}><option value="active">ใช้งานอยู่</option><option value="inactive">ปิดใช้งาน</option></select>
      {err && <div className="r">{err}</div>}
      <button className="btn" disabled={busy || !f.name.trim()} onClick={async () => (await run(() => saveCustomer({ id: c?.id, ...f, name: f.name.trim(), creditLimit: +f.creditLimit || 0 }))) && onClose()}>บันทึก</button></div></Sheet>)
}
