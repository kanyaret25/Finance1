import test from 'node:test'
import assert from 'node:assert/strict'
import { computeSummary, makeReversal, splitLoanPayment, splitExtension } from '../src/lib/ledger.js'
import { canOpenLoan, canExtend } from '../src/lib/rules.js'

const S = { startingCapital: 20000 }
const tx = (type, amount, id) => ({ id, type, amount })

test('ตัวอย่างข้อ 28: ปล่อย 3,000 → พร้อมใช้ 17,000', () => {
  const s = computeSummary([tx('loan_out', 1000), tx('loan_out', 2000)], S)
  assert.equal(s.rotating, 3000)
  assert.equal(s.capitalAvailable, 17000)
  assert.equal(s.cash, 17000)
})

test('A คืน 1,100 → ทุนกลับ 18,000 กำไร 100; ถอน 50 ไม่ลดทุน', () => {
  const loan = { principal: 1000, profit: 100 }
  const { principal, profit } = splitLoanPayment(loan, 1100)
  assert.deepEqual({ principal, profit }, { principal: 1000, profit: 100 })
  const base = [tx('loan_out', 1000), tx('loan_out', 2000), tx('principal_in', principal), tx('profit_in', profit)]
  let s = computeSummary(base, S)
  assert.equal(s.capitalAvailable, 18000)
  assert.equal(s.netProfit, 100)
  s = computeSummary([...base, tx('personal_withdrawal', 50)], S)
  assert.equal(s.profitBalance, 50)
  assert.equal(s.capitalAvailable, 18000)
  assert.equal(s.expenses, 0)
  assert.equal(s.cash, 18050)
})

test('ยกเลิกรายการด้วยการกลับรายการ ยอดกลับเหมือนเดิม', () => {
  const t = { id: 'a', type: 'expense', amount: 300 }
  assert.equal(computeSummary([t, makeReversal(t)], S).expenses, 0)
})

test('เครดิตสินค้า: ต้นทุนหมุน แล้วกลับเป็นทุน ส่วนต่างเป็นกำไร', () => {
  const s = computeSummary([tx('credit_out', 600), tx('credit_paid_cost', 600), tx('credit_paid_profit', 150)], S)
  assert.equal(s.rotating, 0)
  assert.equal(s.creditProfit, 150)
})

test('ต่อดอก: จ่ายแค่กำไร เงินต้นยังค้าง', () => {
  assert.deepEqual(splitExtension({ principal: 1000, profit: 100 }), { principal: 0, profit: 100 })
})

test('จ่ายเกินยอดค้างไม่ได้', () => {
  assert.throws(() => splitLoanPayment({ principal: 1000, profit: 100 }, 1200))
})

test('กฎ: บิลเปิดสูงสุด 2 และต่อดอกสูงสุด 4', () => {
  assert.equal(canOpenLoan([{ status: 'normal' }, { status: 'due' }]).ok, false)
  assert.equal(canOpenLoan([{ status: 'normal' }, { status: 'closed' }]).ok, true)
  assert.equal(canExtend({ extensionCount: 3 }).ok, true)
  assert.equal(canExtend({ extensionCount: 4 }).ok, false)
})

import { receivables } from '../src/lib/ledger.js'
import { loanStatus } from '../src/lib/rules.js'
test('ลูกหนี้ = ต้น+กำไรที่ยังไม่รับ เฉพาะบิลที่เปิดอยู่', () => {
  const L = [{ status: 'open', principal: 1000, profit: 100, paidPrincipal: 400, paidProfit: 0 }, { status: 'closed', principal: 500, profit: 50 }]
  assert.equal(receivables(L), 700)
})
test('สถานะบิลตามวันครบกำหนด', () => {
  const l = (d, x = 0) => ({ status: 'open', dueDate: d, extensionCount: x })
  assert.equal(loanStatus(l('2026-09-28'), '2026-09-29'), 'overdue')
  assert.equal(loanStatus(l('2026-10-01'), '2026-09-29'), 'near')
  assert.equal(loanStatus(l('2026-11-01', 1), '2026-09-29'), 'extended')
  assert.equal(loanStatus({ status: 'closed' }), 'closed')
})

import { splitCreditPayment, creditRemain, creditUsed, creditReceivables } from '../src/lib/ledger.js'
test('เครดิตสินค้า: ต้นทุน 600 ขาย 750 จ่าย 400 แล้วจ่ายที่เหลือ', () => {
  let sale = { status: 'open', customerId: 'a', totalCost: 600, totalPrice: 750, profit: 150, paidCost: 0, paidProfit: 0 }
  const p1 = splitCreditPayment(sale, 400)
  assert.deepEqual(p1, { cost: 400, profit: 0 })
  sale = { ...sale, paidCost: 400 }
  assert.equal(creditRemain(sale), 350)
  assert.equal(creditUsed([sale], 'a'), 350)
  assert.deepEqual(splitCreditPayment(sale, 350), { cost: 200, profit: 150 })
  assert.throws(() => splitCreditPayment(sale, 351))
  const txs = [tx('credit_out', 600), tx('credit_paid_cost', 400), tx('credit_paid_cost', 200), tx('credit_paid_profit', 150)]
  const s = computeSummary(txs, S)
  assert.equal(s.rotating, 0); assert.equal(s.creditProfit, 150); assert.equal(s.cash, 20150)
  assert.equal(creditReceivables([{ ...sale, status: 'closed' }]), 0)
})

import { periodReport, monthlyReport, pctChange, day } from '../src/lib/ledger.js'
test('รายงานช่วงเวลา: แยกกำไร/ค่าใช้จ่าย/ถอนส่วนตัว และเทียบ %', () => {
  const at = (m, d, type, amount) => ({ id: `${m}${d}${type}`, type, amount, date: new Date(2026, m, d, 12).toISOString() })
  const txs = [at(7, 10, 'profit_in', 200), at(8, 5, 'profit_in', 100), at(8, 6, 'credit_paid_profit', 150), at(8, 7, 'expense', 50), at(8, 8, 'personal_withdrawal', 60), at(8, 9, 'loan_out', 1000)]
  const r = periodReport(txs, '2026-09-01', '2026-09-30')
  assert.deepEqual([r.loanProfit, r.creditProfit, r.expenses, r.netProfit, r.withdrawn, r.rotated], [100, 150, 50, 200, 60, 1000])
  assert.equal(pctChange(r.netProfit, periodReport(txs, '2026-08-01', '2026-08-31').netProfit), 0)
  assert.equal(pctChange(300, 200), 50); assert.equal(pctChange(5, 0), null)
  const m = monthlyReport(txs, 2, new Date(2026, 8, 20))
  assert.deepEqual(m.map((x) => x.netProfit), [200, 200])
  assert.equal(day(new Date(2026, 8, 5, 23, 30).toISOString()), '2026-09-05')
})

import { buildAlerts } from '../src/lib/alerts.js'
import { searchAll } from '../src/lib/search.js'
test('แจ้งเตือน: วันนี้/ใกล้/เกิน/ต่อ 4 ครั้ง/วงเงิน/ทุนต่ำ', () => {
  const T = '2026-09-29'
  const loans = [{ id: 1, status: 'open', dueDate: T, customerName: 'เอ', extensionCount: 0 }, { id: 2, status: 'open', dueDate: '2026-10-01', customerName: 'บี', extensionCount: 0 },
    { id: 3, status: 'open', dueDate: '2026-09-20', customerName: 'ซี', extensionCount: 4 }]
  const sales = [{ status: 'open', customerId: 'd', totalCost: 800, profit: 100, paidCost: 0, paidProfit: 0, dueDate: '2026-12-01', customerName: 'ดี' }]
  const a = buildAlerts({ loans, creditSales: sales, customers: [{ id: 'd', name: 'ดี', creditLimit: 1000 }], summary: { capitalAvailable: 3000 }, settings: { lowCapitalAlert: 5000 } }, T)
  assert.equal(a.length, 6)
  assert.equal(buildAlerts({ loans: [], creditSales: [], customers: [], summary: { capitalAvailable: 9e9 }, settings: {} }, T).length, 0)
})
test('ค้นหา: ชื่อ เลขบิล สถานะ', () => {
  const data = { customers: [{ id: 'a', name: 'คุณเอ', phone: '081' }], loans: [{ id: 1, billNo: 'L001', customerName: 'คุณเอ', principal: 1000, profit: 100, status: 'open', dueDate: '2026-01-01' }], creditSales: [], transactions: [] }
  assert.equal(searchAll('เอ', data, '2026-09-29').bills.length, 1)
  assert.equal(searchAll('L001', data, '2026-09-29').customers.length, 0)
  assert.equal(searchAll('เกินกำหนด', data, '2026-09-29').bills.length, 1)
})
