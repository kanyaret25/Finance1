import { useState } from 'react'
import { computeSummary, periodReport, monthlyReport, pctChange, day, TYPES, creditRemain } from '../../lib/ledger'
import { Sheet, baht, dshort } from '../../components/ui'
import TxView from './TxView'
import Export from './Export'

const p2 = (n) => String(n).padStart(2, '0')
const ymd = (d) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`
const addD = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x }
const PERIODS = [['today', 'วันนี้'], ['7d', '7 วัน'], ['month', 'เดือนนี้'], ['last', 'เดือนที่แล้ว'], ['custom', 'กำหนดเอง']]
const OUT = ['capital_out', 'loan_out', 'credit_out', 'expense', 'personal_withdrawal']
const fmt = (n) => Math.abs(n).toLocaleString('th-TH')

function range(k, cf, ct) {
  const t = new Date(), mo = (o) => [ymd(new Date(t.getFullYear(), t.getMonth() + o, 1)), ymd(new Date(t.getFullYear(), t.getMonth() + o + 1, 0))]
  if (k === 'today') return [ymd(t), ymd(t), ymd(addD(t, -1)), ymd(addD(t, -1))]
  if (k === '7d') return [ymd(addD(t, -6)), ymd(t), ymd(addD(t, -13)), ymd(addD(t, -7))]
  if (k === 'month') return [mo(0)[0], ymd(t), ...mo(-1)]
  if (k === 'last') return [...mo(-1), ...mo(-2)]
  const len = Math.round((new Date(ct) - new Date(cf)) / 864e5) + 1
  return [cf, ct, ymd(addD(cf, -len)), ymd(addD(cf, -1))]
}

export default function Reports({ data }) {
  const [view, setView] = useState('profit')
  return (
    <>
      <h1>รายงาน</h1>
      <div className="tabs" style={{ marginTop: 12 }}>
        {[['profit', 'กำไร'], ['capital', 'เงินทุน'], ['cal', 'ปฏิทิน'], ['tx', 'รายการ'], ['export', 'ส่งออก']].map(([k, l]) =>
          <button key={k} className={view === k ? 'on' : ''} onClick={() => setView(k)}>{l}</button>)}</div>
      {view === 'profit' && <Profit txs={data.transactions} />}
      {view === 'capital' && <Capital txs={data.transactions} settings={data.settings} />}
      {view === 'cal' && <Calendar loans={data.loans} sales={data.creditSales} />}
      {view === 'tx' && <TxView txs={data.transactions} />}
      {view === 'export' && <Export data={data} />}
    </>
  )
}

function TxList({ title, types, from, to, onClose }) {
  const rows = (window.__txs || []).filter((t) => types.includes(t.type) && (!from || (day(t.date) >= from && day(t.date) <= to))).sort((a, b) => b.date.localeCompare(a.date))
  const total = rows.reduce((s, t) => s + t.amount, 0)
  return (
    <Sheet title={title} onClose={onClose}>
      <div className="list">{rows.map((t) => <div className="row" key={t.id}>
        <div>{TYPES[t.type]}{t.billNo ? ' ' + t.billNo : ''}{t.customerName ? ' · ' + t.customerName : ''}<div className="mut">{dshort(t.date)}{t.note ? ' · ' + t.note : ''}</div></div>
        <b>{fmt(t.amount)}</b></div>)}
        {!rows.length && <div className="mut">ไม่มีรายการในช่วงนี้</div>}
        <div className="row"><b>รวม</b><b>{baht(total)}</b></div></div>
      <button className="btn" style={{ marginTop: 12 }} onClick={onClose}>ปิด</button></Sheet>)
}

function Profit({ txs }) {
  window.__txs = txs
  const [k, setK] = useState('month'), [cf, setCf] = useState(ymd(addD(new Date(), -6))), [ct, setCt] = useState(ymd(new Date()))
  const [drill, setDrill] = useState(null)
  const [from, to, pf, pt] = range(k, cf, ct)
  const r = periodReport(txs, from, to), prev = periodReport(txs, pf, pt), pct = pctChange(r.netProfit, prev.netProfit)
  const months = monthlyReport(txs), max = Math.max(1, ...months.map((m) => Math.abs(m.netProfit)))
  const Row = ({ label, v, types, cls, sign }) => (
    <div className="row" onClick={() => setDrill({ title: label, types, from, to })} style={{ cursor: 'pointer' }}>
      <span>{label}</span><b className={cls}>{sign}{fmt(v)}</b></div>)
  return (
    <>
      <div className="tabs">{PERIODS.map(([id, l]) => <button key={id} className={k === id ? 'on' : ''} onClick={() => setK(id)}>{l}</button>)}</div>
      {k === 'custom' && <div className="grid" style={{ marginBottom: 12 }}><input type="date" value={cf} onChange={(e) => setCf(e.target.value)} /><input type="date" value={ct} onChange={(e) => setCt(e.target.value)} /></div>}
      <div className="card"><div className="mut">กำไรสุทธิ</div><div className={'big ' + (r.netProfit < 0 ? 'r' : 'g')}>{r.netProfit < 0 ? '−' : ''}{baht(Math.abs(r.netProfit))}</div>
        {pct === null ? <span className="chip done">ยังไม่มีข้อมูลช่วงก่อนหน้าให้เทียบ</span>
          : <span className={'chip ' + (pct >= 0 ? 'ok' : 'bad')}>{pct >= 0 ? '▲' : '▼'} {Math.abs(pct)}% จากช่วงก่อนหน้า</span>}</div>
      <div className="card list">
        <Row label="กำไรจากเงินกู้" v={r.loanProfit} types={['profit_in']} cls="g" sign="+" />
        <Row label="กำไรจากเครดิตสินค้า" v={r.creditProfit} types={['credit_paid_profit']} cls="g" sign="+" />
        <Row label="รายได้อื่น" v={r.otherIncome} types={['other_income']} cls="g" sign="+" />
        <Row label="ค่าใช้จ่ายธุรกิจ" v={r.expenses} types={['expense']} cls="r" sign="−" /></div>
      <div className="card" style={{ background: 'var(--pink)' }} onClick={() => setDrill({ title: 'ถอนใช้ส่วนตัว', types: ['personal_withdrawal'], from, to })}>
        <div className="row"><span>📤 ถอนใช้ส่วนตัว <span className="mut">(ไม่ใช่ค่าใช้จ่าย)</span></span><b>{baht(r.withdrawn)}</b></div>
        <div className="row"><span className="mut">เงินหมุนในช่วงนี้ (ปล่อยกู้ + ขายเครดิต)</span><b>{baht(r.rotated)}</b></div></div>
      <div className="card"><div className="mut" style={{ marginBottom: 8 }}>กำไรแต่ละเดือน (6 เดือน)</div>
        <div className="row" style={{ alignItems: 'flex-end', height: 120 }}>{months.map((m) => (
          <div key={m.key} style={{ textAlign: 'center', flex: 1 }}><small className="mut">{m.netProfit ? fmt(m.netProfit) : ''}</small>
            <div style={{ height: Math.max(4, Math.abs(m.netProfit) / max * 80), background: m.netProfit < 0 ? 'var(--red)' : 'var(--main)', borderRadius: '10px 10px 4px 4px', margin: '0 5px' }} />
            <small className="mut">{m.label}</small></div>))}</div></div>
      {drill && <TxList {...drill} onClose={() => setDrill(null)} />}
    </>
  )
}

function Capital({ txs, settings }) {
  window.__txs = txs
  const [drill, setDrill] = useState(null), s = computeSummary(txs, settings)
  const sm = (...t) => txs.filter((x) => t.includes(x.type)).reduce((a, x) => a + x.amount, 0)
  const rows = [['ทุนเริ่มต้น', settings.startingCapital, null, ''], ['เงินทุนที่เพิ่ม', sm('capital_in'), ['capital_in'], '+'], ['เงินทุนที่ถอน', sm('capital_out'), ['capital_out'], '−'],
    ['เงินต้นที่กลับมา', sm('principal_in', 'credit_paid_cost'), ['principal_in', 'credit_paid_cost'], '+'], ['เงินต้นที่ปล่อยออก', sm('loan_out', 'credit_out'), ['loan_out', 'credit_out'], '−']]
  return (
    <>
      <div className="card list">{rows.map(([l, v, t, sg]) => (
        <div className="row" key={l} onClick={() => t && setDrill({ title: l, types: t })} style={{ cursor: t ? 'pointer' : 'default' }}>
          <span>{l}</span><b className={sg === '−' ? 'r' : sg === '+' ? 'g' : ''}>{sg}{fmt(v)}</b></div>))}
        <div className="row"><b>= ทุนที่พร้อมหมุนต่อ</b><b>{baht(s.capitalAvailable)}</b></div></div>
      <div className="card list">
        <div className="row"><span>กำไรคงเหลือ</span><b className="g">{baht(s.profitBalance)}</b></div>
        <div className="row"><span>เงินต้นที่กำลังหมุน</span><b>{baht(s.rotating)}</b></div>
        <div className="row"><b>เงินสดพร้อมใช้ (ทุน + กำไรคงเหลือ)</b><b>{baht(s.cash)}</b></div></div>
      <div className="note">แตะแต่ละแถวเพื่อตรวจย้อนกลับไปยังรายการเงินเข้า-ออก</div>
      {drill && <TxList {...drill} onClose={() => setDrill(null)} />}
    </>
  )
}

function Calendar({ loans, sales }) {
  const today = ymd(new Date()), [ym, setYm] = useState([new Date().getFullYear(), new Date().getMonth()]), [sel, setSel] = useState(today)
  const items = [
    ...loans.filter((l) => l.status !== 'closed').map((l) => ({ id: l.id, kind: 'เงินกู้', bill: l.billNo, who: l.customerName, due: l.dueDate, amt: (l.principal - (l.paidPrincipal ?? 0)) + (l.profit - (l.paidProfit ?? 0)) })),
    ...sales.filter((s) => s.status !== 'closed').map((s) => ({ id: s.id, kind: 'เครดิต', bill: s.billNo, who: s.customerName, due: s.dueDate, amt: creditRemain(s) }))]
  const kind = (d) => { const n = Math.round((new Date(d) - new Date(today)) / 864e5); return n < 0 ? 'k' : n === 0 ? 'red' : n <= 3 ? 'yellow' : n <= 7 ? 'orange' : 'later' }
  const [y, m] = ym, first = new Date(y, m, 1).getDay(), count = new Date(y, m + 1, 0).getDate()
  const cells = [...Array(first).fill(null), ...Array.from({ length: count }, (_, i) => `${y}-${p2(m + 1)}-${p2(i + 1)}`)]
  const over = items.filter((i) => i.due < today)
  const list = sel === 'over' ? over : items.filter((i) => i.due === sel)
  const move = (n) => setYm([new Date(y, m + n, 1).getFullYear(), new Date(y, m + n, 1).getMonth()])
  return (
    <>
      <div className="card">
        <div className="row" style={{ marginBottom: 8 }}><button className="link" onClick={() => move(-1)}>◀</button>
          <b>{new Date(y, m, 1).toLocaleDateString('th-TH', { month: 'long', year: 'numeric' })}</b><button className="link" onClick={() => move(1)}>▶</button></div>
        <div className="cal">{['อา', 'จ', 'อ', 'พ', 'พฤ', 'ศ', 'ส'].map((d) => <small key={d}>{d}</small>)}
          {cells.map((c, i) => c ? <button key={c} className={sel === c ? 'sel' : ''} onClick={() => setSel(c)}>{+c.slice(8)}
            {items.some((x) => x.due === c) && <i className={kind(c)} />}</button> : <span key={i} />)}</div>
        <div className="legend"><span>🔴 วันนี้</span><span>🟡 ภายใน 3 วัน</span><span>🟠 ภายใน 7 วัน</span><span>⚫ เกินกำหนด</span></div></div>
      {over.length > 0 && <button className="btn sec" style={{ marginBottom: 12 }} onClick={() => setSel('over')}>⚫ เกินกำหนด {over.length} รายการ · {baht(over.reduce((s, i) => s + i.amt, 0))}</button>}
      <div className="card list"><div className="mut">{sel === 'over' ? 'รายการเกินกำหนด' : 'ต้องเก็บวันที่ ' + dshort(sel)}</div>
        {list.map((i) => <div className="row" key={i.id}><div><b>{i.who}</b><div className="mut">{i.kind} {i.bill}{sel === 'over' ? ' · ครบ ' + dshort(i.due) : ''}</div></div><b className="r">{baht(i.amt)}</b></div>)}
        {!list.length && <div className="mut">ไม่มีรายการที่ต้องเก็บ</div>}</div>
    </>
  )
}
