import { reportDefs, downloadCsv, printPdf } from '../../lib/export'

export default function Export({ data }) {
  return (
    <>
      <div className="mut" style={{ marginBottom: 12 }}>CSV เปิดใน Excel ได้เลย · PDF จะเปิดหน้ารายงานแล้วให้เลือก “บันทึกเป็น PDF”</div>
      {reportDefs(data).map((r) => (
        <div className="card" key={r.id}><div className="row"><b>{r.title}</b><span className="mut">{r.rows.length} แถว</span></div>
          <div className="btns"><button className="btn sec" onClick={() => downloadCsv(r.id, r.headers, r.rows)}>Excel / CSV</button>
            <button className="btn sec" onClick={() => printPdf(r.title, r.headers, r.rows)}>PDF</button></div></div>))}
    </>
  )
}
