import { useState } from 'react'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth } from '../../lib/firebase'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit() {
    setBusy(true); setError('')
    try { await signInWithEmailAndPassword(auth, email, password) }
    catch { setError('อีเมลหรือรหัสผ่านไม่ถูกต้อง ลองพิมพ์ใหม่อีกครั้ง') }
    setBusy(false)
  }

  return (
    <div className="login">
      <h1>บ้านปูน Finance</h1>
      <p className="muted">เข้าสู่ระบบเพื่อดูเงินทุนและกำไร</p>
      <input type="email" placeholder="อีเมล" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="รหัสผ่าน" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
      {error && <p className="error">{error}</p>}
      <button className="btn" disabled={busy || !email || !password} onClick={submit}>เข้าสู่ระบบ</button>
    </div>
  )
}
