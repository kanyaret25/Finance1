import { useEffect, useState } from 'react'
import { listen } from '../lib/db'

export function useData() {
  const [d, setD] = useState({ customers: [], loans: [], transactions: [], creditSales: [], products: [], settings: undefined, ready: false })
  useEffect(() => {
    const un = ['customers', 'loans', 'transactions', 'creditSales', 'products'].map((n) => listen(n, (rows) => setD((p) => ({ ...p, [n]: rows }))))
    un.push(listen('settings', (rows) => setD((p) => ({ ...p, settings: rows.find((r) => r.id === 'main'), ready: true }))))
    return () => un.forEach((u) => u())
  }, [])
  return d
}
