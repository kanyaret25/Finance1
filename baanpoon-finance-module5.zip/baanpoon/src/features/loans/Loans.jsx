import { useState } from 'react'
import { Sheet, baht, dshort, useAction } from '../../components/ui'
import { splitLoanPayment, splitExtension } from '../../lib/ledger'
import { canExtend, loanStatus, MAX_EXTENSIONS } from '../../lib/rules'
import { openLoan, payLoan, extendLoan } from '../../lib/db'

const CH = { normal: ['ok', '🟢 ปกติ'], near: ['warn', '🟡 ใกล้ครบกำหนด'], overdue: ['bad', '🔴 เกินกำหนด'], extended: ['blue', '🔵 ต่อดอก'], closed: ['done', '⚫ ปิดแล้ว'] }
const addDays = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10)
const remain = (l) => [l.principal - (l.paidPrincipal ?? 0), l.profit - (l.paidProfit ?? 0)]

export default function Loans({ customers, loans }) {
  const [sheet, setSheet] = useState(null)
  const list = loans.filter((l) => l.status !== 'closed').sort((a, b) => a.dueDate.localeCompare(b.dueDate))
  const close = () => setSheet(null)
  return (
    <>
      <h1>เงินกู้</h1><div className="mut">บิลที่เปิดอยู่ {list.length} บิล</div><h2 />
      {list.map((l) => { const [rp, rf] = remain(l), ch = CH[loanStatus(l)], ext = l.extensionCount ?? 0; return (
        <div className="card" key={l.id}>
          <div className="row"><b>{l.billNo} · {l.customerName}</b><span className={'chip ' + ch[0]}>{ch[1]}</span></div>
          <div className="row" style={{ marginTop: 8 }}>
            <div><div className="mut">เงินต้นค้าง</div><b>{baht(rp)}</b></div>
            <div><div className="mut">กำไรค้าง</div><b className="g">+{rf.toLocaleString('th-TH')}</b></div>
            <div><div className="mut">ครบกำหนด</div><b>{dshort(l.dueDate)}</b></div></div>
          <div className="mut" style={{ marginTop: 8 }}>ต่อดอก {ext}/{MAX_EXTENSIONS}</div>
          <div className="bar"><i style={{ width: ext * 25 + '%' }} /></div>
          {ext >= MAX_EXTENSIONS && <div className="alert" style={{ margin: '8px 0 0' }}>{canExtend(l).message}</div>}
          <div className="btns"><button className="btn" onClick={() => setSheet(['pay', l])}>รับชำระ</button>
            <button className="btn sec" onClick={() => setSheet(['ext', l])}>ต่อดอก</button></div></div>) })}
      {!list.length && <div className="card mut">ยังไม่มีบิลเงินกู้ที่เปิดอยู่</div>}
      <button className="btn" onClick={() => setSheet(['new'])}>+ เปิดบิลใหม่</button>
      {sheet?.[0] === 'new' && <NewLoan customers={customers} loans={loans} onClose={close} />}
      {sheet?.[0] === 'pay' && <Pay loan={sheet[1]} onClose={close} />}
      {sheet?.[0] === 'ext' && <Extend loan={sheet[1]} onClose={close} />}
    </>
  )
}

function NewLoan({ customers, loans, onClose }) {
  const [cid, setCid] = useState(customers[0]?.id || ''), [p, setP] = useState(''), [pr, setPr] = useState(''), [due, setDue] = useState(addDays(30))
  const { busy, err, run } = useAction()
  const c = customers.find((x) => x.id === cid)
  return (
    <Sheet title="เปิดบิลเงินกู้ใหม่" onClose={onClose}>
      {!customers.length ? <p className="mut">เพิ่มลูกค้าก่อนที่หน้า “ลูกค้า”</p> : <div className="form">
        <select value={cid} onChange={(e) => setCid(e.target.value)}>{customers.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select>
        <input type="number" inputMode="decimal" placeholder="เงินต้นที่ให้ (เช่น 1000)" value={p} onChange={(e) => setP(e.target.value)} />
        <input type="number" inputMode="decimal" placeholder="กำไร (เช่น 100)" value={pr} onChange={(e) => setPr(e.target.value)} />
        <div className="mut">วันครบกำหนด</div><input type="date" value={due} onChange={(e) => setDue(e.target.value)} />
        {+p > 0 && <div className="card" style={{ margin: 0, background: 'var(--soft)' }}>ลูกค้าต้องคืน <b>{baht(+p + +pr)}</b></div>}
        {err && <div className="r">{err}</div>}
        <button className="btn" disabled={busy || !c || !(+p > 0) || !due} onClick={async () =>
          (await run(() => openLoan({ customer: c, loans, principal: +p, profit: +pr || 0, dueDate: due }))) && onClose()}>บันทึกบิล</button></div>}
    </Sheet>)
}

function Pay({ loan, onClose }) {
  const [rp, rf] = remain(loan), [amt, setAmt] = useState(String(rp + rf))
  const { busy, err, run } = useAction()
  let s = null, msg = ''
  try { if (+amt > 0) s = splitLoanPayment(loan, +amt) } catch (e) { msg = e.message }
  return (
    <Sheet title={`รับชำระ ${loan.billNo} · ${loan.customerName}`} onClose={onClose}><div className="form">
      <div className="mut">ยอดค้าง {baht(rp + rf)}</div>
      <input type="number" inputMode="decimal" value={amt} onChange={(e) => setAmt(e.target.value)} />
      <div className="card" style={{ margin: 0, background: 'var(--soft)' }}>{s ? <>
        <div className="row"><span>เงินต้นกลับเข้าทุน</span><b>{baht(s.principal)}</b></div>
        <div className="row"><span>กำไรสะสม</span><b className="g">+{s.profit.toLocaleString('th-TH')}</b></div></> : <span className="r">{msg || 'กรอกจำนวนเงิน'}</span>}</div>
      {err && <div className="r">{err}</div>}
      <button className="btn" disabled={busy || !s} onClick={async () => (await run(() => payLoan(loan, +amt))) && onClose()}>บันทึกการรับชำระ</button></div></Sheet>)
}

function Extend({ loan, onClose }) {
  const [due, setDue] = useState(addDays(30)), { busy, err, run } = useAction()
  const chk = canExtend(loan), n = (loan.extensionCount ?? 0) + 1
  return (
    <Sheet title={`ต่อดอก ${loan.billNo} · ${loan.customerName}`} onClose={onClose}>
      {!chk.ok ? <><p>{chk.message}</p><button className="btn" onClick={onClose}>เข้าใจแล้ว</button></> : <div className="form">
        <div className="card" style={{ margin: 0, background: 'var(--soft)' }}>
          <div className="row"><span>ต่อดอกครั้งที่</span><b>{n}/{MAX_EXTENSIONS}</b></div>
          <div className="row"><span>ลูกค้าจ่ายกำไร</span><b className="g">+{splitExtension(loan).profit.toLocaleString('th-TH')}</b></div>
          <div className="mut">เงินต้น {baht(remain(loan)[0])} ยังค้างอยู่</div></div>
        <div className="mut">ครบกำหนดใหม่</div><input type="date" value={due} onChange={(e) => setDue(e.target.value)} />
        {err && <div className="r">{err}</div>}
        <button className="btn" disabled={busy || !due} onClick={async () => (await run(() => extendLoan(loan, due))) && onClose()}>ยืนยันต่อดอก</button></div>}
    </Sheet>)
}
