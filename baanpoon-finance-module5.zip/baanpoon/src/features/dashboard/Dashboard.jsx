import { useState } from 'react'
import { computeSummary, receivables, creditReceivables, creditUsed, TYPES } from '../../lib/ledger'
import { loanStatus } from '../../lib/rules'
import { buildAlerts } from '../../lib/alerts'
import { Sheet, baht, dshort } from '../../components/ui'

const PROFIT = ['profit_in', 'credit_paid_profit', 'other_income', 'expense']
const CARDS = [
  ['เงินทุน', '💰', 'capitalNet', ['capital_in', 'capital_out'], ['capital_out'], ''],
  ['เงินกำลังหมุน', '🔄', 'rotating', ['loan_out', 'credit_out', 'principal_in', 'credit_paid_cost'], ['principal_in', 'credit_paid_cost'], ''],
  ['ลูกหนี้', '👥', 'debt', null, [], 'r'],
  ['กำไรสะสม', '📈', 'netProfit', PROFIT, ['expense'], 'g'],
  ['ถอนใช้ส่วนตัว', '📤', 'withdrawn', ['personal_withdrawal'], [], ''],
  ['กำไรคงเหลือ', '✨', 'profitBalance', [...PROFIT, 'personal_withdrawal'], ['expense', 'personal_withdrawal'], 'g'],
]

export default function Dashboard({ data }) {
  const { transactions, loans, settings, creditSales, customers } = data
  const s = { ...computeSummary(transactions, settings), debt: receivables(loans) + creditReceivables(creditSales) }
  const [drill, setDrill] = useState(null)
  const st = [...loans, ...creditSales].map(loanStatus)
  const over = st.filter((x) => x === 'overdue').length, near = st.filter((x) => x === 'near').length
  const maxed = loans.filter((l) => l.status !== 'closed' && (l.extensionCount ?? 0) >= 4).length

  const nearLimit = customers.filter((c) => c.creditLimit > 0 && creditUsed(creditSales, c.id) / c.creditLimit >= 0.8).length
  const asLoans = creditSales.map((s) => ({ ...s, principal: s.totalCost, paidPrincipal: s.paidCost }))
  const alerts = buildAlerts({ loans, creditSales, customers, summary: s, settings })
  const rows = (c) => {
    if (!c[3]) return [...loans, ...asLoans].filter((l) => l.status !== 'closed').map((l) => ({
      id: l.id, label: `${l.billNo} ${l.customerName}`, sub: `ครบ ${dshort(l.dueDate)}`,
      v: (l.principal - (l.paidPrincipal ?? 0)) + (l.profit - (l.paidProfit ?? 0)) }))
    const r = transactions.filter((t) => c[3].includes(t.type)).sort((a, b) => b.date.localeCompare(a.date)).map((t) => ({
      id: t.id, label: `${TYPES[t.type]}${t.billNo ? ' ' + t.billNo : ''}${t.customerName ? ' · ' + t.customerName : ''}`,
      sub: dshort(t.date), v: (c[4].includes(t.type) ? -1 : 1) * t.amount }))
    return c[2] === 'capitalNet' ? [...r, { id: 'start', label: 'ทุนเริ่มต้น', sub: '', v: settings.startingCapital }] : r
  }

  return (
    <>
      <h1>สวัสดีค่ะ 👋</h1><div className="mut">ภาพรวมเงินของบ้านปูนตอนนี้</div><h2 />
      <div className="card hero"><div className="mut">💵 เงินสดพร้อมใช้</div><div className="big">{baht(s.cash)}</div>
        <div className="mut">ทุน {baht(s.capitalNet)} + กำไรคงเหลือ {baht(s.profitBalance)} − เงินหมุน {baht(s.rotating)}</div></div>
      {alerts.length > 0 && <div className="alert">{alerts.map((a) => <div key={a}>{a}</div>)}</div>}
      <div className="grid">{CARDS.map((c) => (
        <button key={c[0]} className="card" onClick={() => setDrill(c)}>
          <div className="mut">{c[1]} {c[0]}</div><div className={'n ' + c[5]}>{baht(s[c[2]])}</div></button>))}</div>
      <div className="note">แตะการ์ดเพื่อดูว่าตัวเลขมาจากรายการไหน</div>
      {drill && <Sheet title={`${drill[0]} มาจากไหน`} onClose={() => setDrill(null)}>
        <div className="list">{rows(drill).map((r) => <div className="row" key={r.id}><div>{r.label}<div className="mut">{r.sub}</div></div>
          <b className={r.v < 0 ? 'r' : 'g'}>{r.v < 0 ? '−' : '+'}{Math.abs(r.v).toLocaleString('th-TH')}</b></div>)}
          {!rows(drill).length && <div className="mut">ยังไม่มีรายการ</div>}
          <div className="row"><b>รวม</b><b>{baht(s[drill[2]])}</b></div></div>
        <button className="btn" style={{ marginTop: 12 }} onClick={() => setDrill(null)}>ปิด</button></Sheet>}
    </>
  )
}
