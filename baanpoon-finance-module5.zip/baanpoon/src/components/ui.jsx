import { useState } from 'react'
export const baht = (n) => '฿' + Number(n).toLocaleString('th-TH')
export const dshort = (d) => new Date(d).toLocaleDateString('th-TH', { day: 'numeric', month: 'short' })

export function Sheet({ title, onClose, children }) {
  return (
    <div className="sheet-bg show" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sheet"><h2 style={{ marginTop: 0 }}>{title}</h2>{children}</div>
    </div>
  )
}

export function useAction() {
  const [busy, setBusy] = useState(false), [err, setErr] = useState('')
  const run = async (fn) => {
    setBusy(true); setErr('')
    try { await fn(); setBusy(false); return true }
    catch (e) { setErr(e.message); setBusy(false); return false }
  }
  return { busy, err, run }
}

export function AmountForm({ title, label, hint, onSubmit, onClose }) {
  const [amt, setAmt] = useState(''), [note, setNote] = useState('')
  const { busy, err, run } = useAction()
  return (
    <Sheet title={title} onClose={onClose}>
      <div className="form">
        {hint && <div className="mut">{hint}</div>}
        <input type="number" inputMode="decimal" placeholder="จำนวนเงิน" value={amt} onChange={(e) => setAmt(e.target.value)} />
        <input placeholder="หมายเหตุ (ถ้ามี)" value={note} onChange={(e) => setNote(e.target.value)} />
        {err && <div className="r">{err}</div>}
        <button className="btn" disabled={busy || !(+amt > 0)} onClick={async () => (await run(() => onSubmit(+amt, note))) && onClose()}>{label}</button>
      </div>
    </Sheet>
  )
}
